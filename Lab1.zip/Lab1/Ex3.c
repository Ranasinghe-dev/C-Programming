/*Write a C program to print your name, 
date of birth and student ID number in following format.

Name : Thedas Perera
DOB : July 14, 1999
ID : IT21234567


(NOTE: Use one printf statement)
*/

#include <stdio.h>
int main(void)
{
	
	printf("Name : Tharindi Lakchani\nDOB : Nove. 28, 1997\nID : IT18153378\n" );
	
	return 0;
}//end of function main
