#include <stdio.h>
int main(void)
{
	/*Display "My First C Program" 
	The words are separated by tabs*/
	
	printf("My\tFirst\tC\tProgram\n" );
	
	return 0;
}//end of function main
