//This program display the text "Hello World"

#include <stdio.h>

//function main begins program execution
int main(void)
{
	printf("Hello World!!\n");
	
	return 0;
}//end of function main
