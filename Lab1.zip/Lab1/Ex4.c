/*Write a C program to print following table format 
that includes Student name and prefered subject.

(NOTE : use \n and \t to format your output)
*/

#include <stdio.h>
int main(void)
{
	
	printf("===============\nName\tSubject\n===============\nAmal\tEnglish\nMali\tSinhala\nNipun\tHistory\n" );
	
	return 0;
}//end of function main
